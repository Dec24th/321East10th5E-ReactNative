import React from 'react';
import MainRoom from './components/MainRoom';

export default function AppRooms() {
  return (
    <MainRoom />
  );
}